﻿/**
 * Contains logic for initial spawning of boid population, as well as adding & removing boids to/from the population list
 *  Included are methods for spawning boids, recording all boids in a list, 
 *  .. as well as setting the user defined Alignment, Separation, and Cohesion threshold values. 
 * 
 * @author Zach Sullivan
 * @version	Last_modified May 9, 2018
 *
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoidController : MonoBehaviour {

	public GameObject boid;
	public GameObject obstacle;

	public ArrayList boidList;
	public ArrayList obstacleList;

	private const int POPULATION_SIZE = 50;

	// Use this for initialization
	void Start () {
		
		boidList = new ArrayList();
		obstacleList = new ArrayList ();

		// Spawn an initial population of boids
		for (int i = 0; i < POPULATION_SIZE; i++) {
			addBoid ();
		}
	}

	// Add a boid to the population list
	public void addBoid() {
		GameObject boidObject = Instantiate(boid, new Vector2(0,0), Quaternion.identity);	// Create a new Boid GameObject by obtaining the parent GameObject the boid class is a component of
		Boid boidScript = boidObject.GetComponent<Boid> ();
		boidList.Add (boidScript);
	}

	// Remove the specified boid from the population list
	// @param Boid boid		The specified boid to be removed
	public void removeBoid (Boid boid) {
		boidList.Remove (boid);
	}
		
	// Update is called once per frame
	void Update () {

		// Iterate through each boid in the boidList and update their positions
		foreach (Boid boid in boidList){
			boid.run (boidList);
		}
	}

	// Iterate through each boid in the population and update its minimum seperation range threshold
	// @param float range	The range value to be updated to
	public void updateSepRange (float range) {
		foreach (Boid boid in boidList){
			boid.setSepRange(range);
		}
	}

	// Iterate through each boid in the population and update its seperation scaling threshold
	// @param float scale	The scale value to be updated to
	public void updateSepScale (float scale) {
		foreach (Boid boid in boidList){
			boid.setSepScale(scale);
		}
	}

	// Iterate through each boid in the population and update its minimum alignment range threshold
	// @param float range	The range value to be updated to
	public void updateAlignRange (float range) {
		foreach (Boid boid in boidList){
			boid.setAlignRange(range);
		}
	}

	// Iterate through each boid in the population and update its alignment scaling threshold
	// @param float scale	The scale value to be updated to
	public void updateAlignScale (float scale) {
		foreach (Boid boid in boidList){
			boid.setAlignScale(scale);
		}
	}

	// Iterate through each boid in the population and update its minimum cohesion range threshold
	// @param float range	The range value to be updated to
	public void updateCohRange (float range) {
		foreach (Boid boid in boidList){
			boid.setCohRange(range);
		}
	}

	// Iterate through each boid in the population and update its cohesion scaling threshold
	// @param float scale	The scale value to be updated to
	public void updateCohScale (float scale) {
		foreach (Boid boid in boidList){
			boid.setCohScale(scale);
		}
	}
}
