﻿/**
 * Contains the core logic a for boid agent, included are methods for Alignment, Separation, and Cohesion, 
 * .. as well as methods for updating position & boudining a boid, and setting custom behavior thresholds. 
 * 
 * @author Zach Sullivan
 * @version	Last_modified May 9, 2018
 *
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boid : MonoBehaviour {

	private BoidController boidController;

	private Vector2 vel;
	private Vector2 acc;

	private Vector2 cohSum;	// The sum of all boid position vectors, not including this boid's position vector 
	private Vector2 alignSum;	// The sum of all boid position vectors, not including this boid's position vector 

	private bool isWrappingX;
	private bool isWrappingY;

	private Rigidbody2D rbody;

	private SpriteRenderer spRender;

	private Camera cam;

	private int cohCounter;
	private int alignCounter;

	private float sepRange;
	private float sepScale;

	private float alignRange;
	private float alignScale;

	private float cohRange;
	private float cohScale;

	// Unlike Start, Awake will execute this instance object upon instanciation at runtime
	void Awake () {

		this.boidController = GameObject.Find ("BoidController").GetComponent<BoidController> ();

		this.rbody = GetComponent<Rigidbody2D>();
		this.spRender = GetComponent<SpriteRenderer> ();

		this.cam = Camera.main;

		this.spRender.material.SetColor("_Color", Color.red); 

		this.isWrappingX = false;
		this.isWrappingY = false;

		this.cohCounter = 0;
		this.alignCounter = 0;

		this.sepRange = 0.7f;
		this.sepScale = 0.5f;

		this.alignRange = 1.7f;
		this.alignScale = 1.2f;

		this.cohRange = 0.5f;
		this.cohScale = 1.7f;

		this.cohSum = new Vector2 (0.0f, 0.0f);
		this.alignSum = new Vector2 (0.0f, 0.0f);

		float vx = Random.Range (-10f, 10.0f);
		float vy = Random.Range (-10f, 10.0f);

		this.vel = new Vector2(vx, vy);
		this.acc = new Vector2 (0.0f, 0.0f);
	}

	// Returns the velocity of the current boid
	// @return	Boid's current velocity 
	public Vector2 getVelocity () {
		return this.vel;
	}

	// Updates the boid's seperation range threshold, modifying the minimum distance by which boids can calculate a new seperation vector
	public void setSepRange (float range) {
		this.sepRange = range;
		print ("sepRange: " + this.sepRange);
	}

	// Updates the boid's seperation scale threshold, modifying the x & y vector components of the current seperation vector
	public void setSepScale (float scale) {
		this.sepScale = scale;
		print ("sepScale: " + this.sepScale);
	}
		
	// Updates the boid's alignment range threshold, modifying the minimum distance by which boids can calculate a new alignment vector
	public void setAlignRange (float range) {
		this.alignRange = range;
		print ("alignRange: " + this.alignRange);
	}

	// Updates the boid's alignment scale threshold, modifying the x & y vector components of the current alignment vector
	public void setAlignScale (float scale) {
		this.alignScale = scale;
		print ("alignScale: " + this.alignScale);
	}

	// Updates the boid's cohesion range threshold, modifying the minimum distance by which boids can calculate a new cohesion vector
	public void setCohRange (float range) {
		this.cohRange = range;
		print ("cohRange: " + this.cohRange);
	}

	// Updates the boid's cohesion scale threshold, modifying the x & y vector components of the current cohesion vector
	public void setCohScale (float scale) {
		this.cohScale = scale;
		print ("cohScale: " + this.cohScale);
	}

	// NOTE: iterating through the list of boids ONCE in the run update method improves FPS from ~10 to ~100fps
	// Further FPS gains are made by Unity's default Frustum Culling coupled with the use of a Killbox to destroy gameobjects beyond camera view
	// @param ArrayList boids	Arraylist containing each discrete boid in the simulation
	public void run (ArrayList boids) {

		Vector2 sep = new Vector2 (0,0);
		Vector2 align = new Vector2 (0,0);
		Vector2 coh = new Vector2 (0,0);

		cohCounter = 0;						// Reset the number of nearby cohesive boids found
		alignCounter = 0;					// Reset the number of nearby aligned boids found

		cohSum = new Vector2 (0.0f, 0.0f);	// Reset the cohesion sum
		alignSum = new Vector2 (0.0f, 0.0f);	// Reset the cohesion sum


		// Iterate through each boid and apply the appropriate force to any nearby boids
		foreach (Boid boid in boids) {

			// Obtain the distance from this boid and the next boid
			float dist = Vector2.Distance (this.transform.position, boid.transform.position );

			// Validate that distance against the user defined behaviour range thresholds
			// .. assigning new behaviour vectors when applicable

			// Obtain new seperation 
			if ((dist > 0.0f) && (dist < sepRange)) {
				sep = seperation (boid, dist);	// Pass the current boid and it's distance to the seperation method
			}

			// Obtain new alignment
			if (dist < alignRange) {
				alignCounter += 1;
				align = alignment (boid, alignCounter);
			}

			// Obtain new cohesion
			if ((dist > 0.0f) && dist < cohRange) {
				cohCounter += 1;
				coh = cohesion (boid, cohCounter);
			}
		}

		// Scale each behaviour vector by a user specifed threshold amount
		// NOTE: The effect of behaviour scaling is best visualized when multiple conflicting behaviours have equal range values, 
		// .. providing a stronger scaling to one over the other should result in a visual behaviour bias
		sep.Scale (new Vector2(sepScale, sepScale));
		align.Scale (new Vector2(alignScale, alignScale));
		coh.Scale (new Vector2(cohScale, cohScale));

		applyForce (sep);		// Push boids apart, to avoid any collisions
		applyForce (align);		// Push boids into the same heading
		applyForce (coh);		// Group boids together

		// Update the position and bound the boid to the defined play space
		updatePos ();
		boundPosition ();

	}

	// Apply a new force to the boid's acceleration 
	// @param Vector2 force 	The force to be applied to the boid's acceleration
	public void applyForce (Vector2 force) {
		this.acc = this.acc + force;
	}

	// Updates the boids position on screen
	// .. summing the acceleration to velocity, and velocity to boid position
	public void updatePos () {

		this.vel = this.vel + this.acc;

		float velLen = this.vel.magnitude;

		// Maintain a consistent velocity 
		if (velLen > 1.0f) {
			this.vel.Scale(new Vector2(1.0f / (velLen/ 1.0f), 1.0f / (velLen/ 1.0f)));
		}

		this.acc = Vector2.zero;

		// Calculate a new rotation angle towards the new velocity vector
		// Update the boid's rotation to reflect this new angle
		Quaternion neededRotation = Quaternion.LookRotation(Vector3.forward, this.vel);
		transform.rotation = Quaternion.Lerp(this.transform.rotation, neededRotation, Time.deltaTime * 10);

		// Update the position of the boid on screen
		rbody.velocity = this.vel;
	}
		
	// Bound the boid position in the environment
	// .. if the boid surpasses the environment bounds, wrap the boid around to the opposite side 
	public void boundPosition () {
		
		bool isVisable = true;

		// Ensure the boid is currently visable to the camera
		if (spRender.isVisible) {
			isVisable = true;
		} else {
			isVisable = false;
		}

		// If the boid is currently visable, then we know the boid is not in the process of being teleported
		if (isVisable == true) {
			isWrappingX = false;
			isWrappingY = false;
//			return;
		}

		// If the boid is being teleported, then we do not need to bound its position
		if(isWrappingX == true && isWrappingY == true) {
			return;
		}
			
		Vector2 viewportPosition = cam.WorldToViewportPoint(transform.position);
		Vector2 newPosition = transform.position;

		// Validate boid x coordinates are within camera view space
		if (isWrappingX == false && (viewportPosition.x > 1 || viewportPosition.x < 0)) {
			newPosition.x = -newPosition.x;
			isWrappingX = true;
		}

		// Validate boid y coordinates are within camera view space
		if (isWrappingY == false && (viewportPosition.y > 1 || viewportPosition.y < 0)) {
			newPosition.y = -newPosition.y;
			isWrappingY = true;
		}
			
		// Update the boid's position to reflect the play space bounding
		transform.position = newPosition;

	}

	// Obtain a new 2D vector pointing away from the nearby boid
	// @param Boid boid		The Boid which this Boid is comparing against
	// @param float dist	The distance from this Boid and the compared Boid
	// @return returns a new 2D vector pointing away from nearby boid
	private Vector2 seperation (Boid boid, float dist) {
			
		Vector2 steer = new Vector2 (0.0f, 0.0f);
		Vector2 diff = this.transform.position - boid.transform.position;

		diff = diff.normalized;
		diff = diff / dist;
		steer = steer + diff;

		if (steer.magnitude > 0) {
			steer = steer.normalized;
			steer = steer - this.vel;
		}

		return steer;
	}

	// Obtain a new 2D vector pointing in the same direction as the nearby boid
	// @param Boid boid		The Boid which this Boid is comparing against
	// @param int count		The number of boids currently being averaged together
	// @return returns a new 2D vector pointing in the same direction as the nearby boid
	private Vector2 alignment (Boid boid, int count) {

		// Avoid division by 0, if the count is 0 simply return an empty vector 2 thereby nullifying the alignment vector
		if (count == 0) {
			return new Vector2 (0.0f, 0.0f);
		}
			
		// Calculate the sum of all other boid velocities, and average it
		alignSum += boid.getVelocity ();
		alignSum /= count;

		// Return the normalized trajectory 
		return alignSum.normalized;
	}

	// Obtain a new 2D vector, containing the average position (i.e. centroid) of all nearby boids, calculate steering vector towards that position
	// @param Boid boid		The Boid which this Boid is comparing against
	// @param int count		The number of boids currently flocking together
	// @return returns a new 2D vector pointing towards the center of all nearby boids
	private Vector2 cohesion (Boid boid, int count) {

		// Avoid division by 0, if the count is 0 simply return an empty vector 2 thereby nullifying the cohesion vector
		if (count == 0) {
			return new Vector2 (0.0f, 0.0f);;
		}

		// Calculate the sum of all other boid positions, and average it
		cohSum += new Vector2(boid.gameObject.transform.position.x, boid.gameObject.transform.position.y);
		cohSum /= count;

		// Calculate a new 2D vector from the boid's current position to the centroid sum
		Vector2 cohesion = new Vector2(this.transform.position.x, this.transform.position.y) - cohSum;

		// Return the normalized trajectory 
		return cohesion.normalized;
	}

	// Checks if this boid has collided with any other gameobjects containing collider components
	// @param Collision2D collision		The collision component we have collided with
	void OnCollisionEnter2D (Collision2D collision) {

		// If this boid has collided with the killbox gameobject collider, 
		// .. then we know the boid has left the acceptable place space and should no longer effect the calculations
		// Removing boids which have not successfuly bounded their position, significantly improves performance overtime
		if (collision.gameObject.name == "KillBox") {
			// Remove the boid from the population arraylist, and remove the gameobject from the simulation
			boidController.removeBoid (this);
			Destroy (this.gameObject);
		}
	}

}
