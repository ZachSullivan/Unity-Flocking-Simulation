﻿/**
 * Contains logic for setting user defined Alignment, Separation, and Cohesion threshold values.
 * .. as well as the ability to spawn additional boids
 * 
 * @author Zach Sullivan
 * @version	Last_modified May 9, 2018
 *
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SliderController : MonoBehaviour {

	public BoidController boidController;

	private Button boidSpawner;

	private Slider sepRngSlider;
	private InputField sepRngField;

	// Stores the seperation scaling threshold
	private Slider sepScaSlider;
	private InputField sepScaField;

	// Stores the alignment range threshold
	private Slider alignRngSlider;
	private InputField alignRngField;

	// Stores the alignment scaling threshold
	private Slider alignScaSlider;
	private InputField alignScaField;

	// Stores the cohesion range threshold
	private Slider cohRngSlider;
	private InputField cohRngField;

	// Stores the cohesion scaling threshold
	private Slider cohScaSlider;
	private InputField cohScaField;

	// Follwing are used to store the last used seperation range and scale slider values
	private float oldSepRange;
	private float oldSepScale;

	// Follwing are used to store the last used alignment range and scale slider values
	private float oldAlignRange;
	private float oldAlignScale;

	// Follwing are used to store the last used cohesion range and scale slider values
	private float oldCohRange;
	private float oldCohScale;

	// Use this for initialization
	void Start () {

		// Obtain and assign the corresponding UI components from the respecting parented GameObject
		// Storing the current value of each slider
		boidSpawner = GameObject.Find ("Spawn Boid").GetComponent<Button> ();

		sepRngSlider = GameObject.Find("Sep Range Slider").GetComponent<Slider> ();				
		sepRngField = GameObject.Find("Sep Range InputField").GetComponent<InputField> ();		
		oldSepRange = sepRngSlider.value;

		sepScaSlider = GameObject.Find("Sep Scale Slider").GetComponent<Slider>();
		sepScaField = GameObject.Find("Sep Scale InputField").GetComponent<InputField> ();		
		oldSepScale = sepScaSlider.value;

		alignRngSlider = GameObject.Find("Align Range Slider").GetComponent<Slider> ();	
		alignRngField = GameObject.Find("Align Range InputField").GetComponent<InputField> ();	
		oldAlignRange = alignRngSlider.value;

		alignScaSlider = GameObject.Find("Align Scale Slider").GetComponent<Slider>();
		alignScaField = GameObject.Find("Align Scale InputField").GetComponent<InputField> ();	
		oldAlignScale = alignScaSlider.value;

		cohRngSlider = GameObject.Find("Coh Range Slider").GetComponent<Slider> ();	
		cohRngField = GameObject.Find("Coh Range InputField").GetComponent<InputField> ();	
		oldCohRange = cohRngSlider.value;

		cohScaSlider = GameObject.Find("Coh Scale Slider").GetComponent<Slider>();
		cohScaField = GameObject.Find("Coh Scale InputField").GetComponent<InputField> ();	
		oldCohScale = cohScaSlider.value;

		addEventListeners();

	}

	// Applies a listener to each UI compnent, updates the corresponding textfield to display the current slider values
	private void addEventListeners () {

		// Apply a Listener to the spawner button, allowing the user to spawn additional boids
		boidSpawner.onClick.AddListener(spawnBoid);

		sepRngSlider.onValueChanged.AddListener ( delegate {
			sepRngField.text = sepRngSlider.value.ToString();
		});

		sepScaSlider.onValueChanged.AddListener ( delegate {
			sepScaField.text = sepScaSlider.value.ToString();
		});

		alignRngSlider.onValueChanged.AddListener ( delegate {
			alignRngField.text = alignRngSlider.value.ToString();
		});

		alignScaSlider.onValueChanged.AddListener ( delegate {
			alignScaField.text = alignScaSlider.value.ToString();
		});

		cohRngSlider.onValueChanged.AddListener ( delegate {
			cohRngField.text = cohRngSlider.value.ToString();
		});

		cohScaSlider.onValueChanged.AddListener ( delegate {
			cohScaField.text = cohScaSlider.value.ToString();
		});
	}

	void Update () {
		// If the user has released the mouse, check if any threshold values have changed
		if (Input.GetMouseButtonUp(0)) {
			OnMouseUp ();
		}
	}

	// Spawns additional boids in the boidcontroller class
	void spawnBoid () {
		boidController.addBoid ();
	}

	// Checks if any of the slider values have changed from their last saved states
	void OnMouseUp() {

		// If the seperation range has changed, tell the boid controller to update all boids
		// Save the current slider value for later comparison 
		if (sepRngSlider.value != oldSepRange) {
			boidController.updateSepRange(sepRngSlider.value);
			oldSepRange = sepRngSlider.value;
		}

		// If the seperation scale has changed, tell the boid controller to update all boids
		// Save the current slider value for later comparison 
		if (sepScaSlider.value != oldSepScale) {
			boidController.updateSepScale(sepScaSlider.value);
			oldSepScale = sepScaSlider.value;
		}

		// If the alignment range has changed, tell the boid controller to update all boids
		// Save the current slider value for later comparison 
		if (alignRngSlider.value != oldAlignRange) {
			boidController.updateAlignRange(alignRngSlider.value);
			oldAlignRange = alignRngSlider.value;
		}

		// If the alignment scale has changed, tell the boid controller to update all boids
		// Save the current slider value for later comparison 
		if (alignScaSlider.value != oldAlignScale) {
			boidController.updateAlignScale(alignScaSlider.value);
			oldAlignScale = alignScaSlider.value;
		}

		// If the cohesion range has changed, tell the boid controller to update all boids
		// Save the current slider value for later comparison 
		if (cohRngSlider.value != oldCohRange) {
			boidController.updateCohRange(cohRngSlider.value);
			oldCohRange = cohRngSlider.value;
		}

		// If the cohesion scale has changed, tell the boid controller to update all boids
		// Save the current slider value for later comparison 
		if (cohScaSlider.value != oldCohScale) {
			boidController.updateCohScale(cohScaSlider.value);
			oldCohScale = cohScaSlider.value;
		}
	}
}
